package com.example.fixofinal.model

class Centro  (
    val id_centro: String,
    val nome_centro: String,
    val morada: String,
    val estado: String
)
