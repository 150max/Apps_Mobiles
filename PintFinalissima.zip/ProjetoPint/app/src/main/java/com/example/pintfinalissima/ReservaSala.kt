package com.example.pintfinalissima

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import org.json.JSONObject
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

class ReservaSala : AppCompatActivity(), TimePickerDialog.OnTimeSetListener, DatePickerDialog.OnDateSetListener {
    lateinit var preferences: SharedPreferences
    lateinit var preferences4: SharedPreferences

    private var isInicio =0
    private var anoAgora = 0
    private var monthAgora = 0
    private var updatedataReserva = ""
    private var updatehoraInicio = ""
    private var updatehoraFim = ""
    private var dayAgora = 0
    private var horaAgora = 0
    private var minuteAgora = 0
    private var anoAgoraString = ""
    private var monthAgoraString  = ""
    private var dayAgoraString  = ""
    private var horaAgoraString  = ""
    private var minuteAgoraString  = ""
    private var savedDay = 0
    private var savedMonth = 0
    private var savedYear = 0
    private var savedHoraInicio = 0
    private var savedMinutoInicio = 0
    private var savedHoraFim = 0
    private var savedMinutoFim = 0
    private var savedDateString = ""
    private var savedHourFimString= ""
    private var savedHourInicioString= ""
    private var idUser = ""
    private var idSala:Int = 0



    private fun registerSala(){
        val url = "https://backend-pint-final.herokuapp.com/api/mobile/postreserva"
        val jsonObject = JSONObject()
        jsonObject.put("data", updatedataReserva)
        jsonObject.put("horainicio", updatehoraInicio)
        jsonObject.put("horafim", updatehoraFim)
        //jsonObject.put("centro", id_centro)
        jsonObject.put("idutilizador", idUser)
        jsonObject.put("sala", idSala)
        Log.d("JSON check", jsonObject.toString())
        val req = JsonObjectRequest(
            Request.Method.POST, url,jsonObject,
            { response ->
                // response
                if(response.has("dados")){
                    Log.d("register", "Deubem")
                    Toast.makeText(applicationContext,"Sala Reservada", Toast.LENGTH_SHORT).show()

                }else{
                    Toast.makeText(applicationContext,"Sala já ocupada, ir consultar horario!", Toast.LENGTH_SHORT).show()
                }

            },
            { error ->
                Log.d("API", "error => $url $error")
                Toast.makeText(applicationContext,"Sala já ocupada, ir consultar horario!", Toast.LENGTH_SHORT).show()
            }
        )

        MySingleton.getInstance(this).addToRequestQueue(req)
    }
    private fun getTimeNow(){
        val current = LocalDateTime.now()

        val dayformatter = DateTimeFormatter.ofPattern("dd")
        dayAgoraString = current.format(dayformatter).toString()
        dayAgora = dayAgoraString.toInt()

        val monthformatter = DateTimeFormatter.ofPattern("MM")
        monthAgoraString = current.format(monthformatter).toString()
        monthAgora = monthAgoraString.toInt()

        val yearformatter = DateTimeFormatter.ofPattern("yyyy")
        anoAgoraString = current.format(yearformatter).toString()
        anoAgora = anoAgoraString.toInt()


        val horaformatter = DateTimeFormatter.ofPattern("HH")
        horaAgoraString = current.format(horaformatter).toString()
        horaAgora= horaAgoraString.toInt()

        val minuteformatter = DateTimeFormatter.ofPattern("mm")
        minuteAgoraString = current.format(minuteformatter).toString()
        minuteAgora = minuteAgoraString.toInt()
    }


    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reservar_sala)
        getTimeNow();

        idSala = intent.getIntExtra("id_sala",0)
        Log.d("O valor da idsala é", idSala.toString())



        preferences = getSharedPreferences("sharedpref", Context.MODE_PRIVATE)
        idUser = preferences.getString("ID","").toString()
        Log.d("O valor da idUser é", idUser)



        val ethoraInicio = findViewById<EditText>(R.id.et_Inicio)
        val ethoraFim = findViewById<EditText>(R.id.et_Fim)
        val etdataReserva = findViewById<EditText>(R.id.et_dataReserva)
        ethoraInicio.hint= "$horaAgoraString:$minuteAgoraString"
        ethoraFim.hint= "$horaAgoraString:$minuteAgoraString"
        etdataReserva.hint = "$dayAgoraString-$monthAgoraString-$anoAgoraString"

        val btnBack = findViewById<Button>(R.id.buttonBack)
        btnBack.setOnClickListener {
            val intent = Intent(this, ListaCentros::class.java)
            startActivity(intent)
            this.finish()
        }
        val btn_dataReserva= findViewById<Button>(R.id.buttonpopupdata)
        btn_dataReserva.setOnClickListener {
            DatePickerDialog(this,this,anoAgora,monthAgora-1,dayAgora).show()
        }
        val btn_horaInicio = findViewById<Button>(R.id.buttoninicio)
        btn_horaInicio.setOnClickListener {
            isInicio=1
            TimePickerDialog(this,this,horaAgora,minuteAgora,true).show()
        }
        val btn_horaFim = findViewById<Button>(R.id.buttonFim)
        btn_horaFim.setOnClickListener {
            isInicio=0
            TimePickerDialog(this,this,horaAgora,minuteAgora,true).show()
        }

        val btnConfirmar = findViewById<Button>(R.id.buttonConfirmar)
        btnConfirmar.setOnClickListener {


            savedHourFimString = ethoraFim.hint.toString()
            Log.d("Hora Fim Guardada->",savedHourFimString)
            savedHourInicioString = ethoraInicio.hint.toString()
            Log.d("Hora Inicio Guardada->",savedHourInicioString)

            val horainicio = "${savedHourInicioString.substring(0,2)}.${savedHourInicioString.substring(3,5)}".toFloat()
            val horafim = "${savedHourFimString.substring(0,2)}.${savedHourFimString.substring(3,5)}".toFloat()

            val current = LocalDateTime.now()
            val formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")
            val dataHoje = current.format(formatter)
            val dataHojeDate: LocalDateTime = LocalDateTime.parse(dataHoje,formatter)
            savedDateString = etdataReserva.hint.toString()

            val parsableDateReserva = "${savedDateString.substring(0,2)}/${savedDateString.substring(3,5)}/${savedDateString.substring(6,10)} ${savedHourInicioString.substring(0,2)}:${savedHourInicioString.substring(3,5)}"
            val dataReservaDate: LocalDateTime = LocalDateTime.parse(parsableDateReserva,formatter)

            val parsableDateReservafim = "${savedDateString.substring(0,2)}/${savedDateString.substring(3,5)}/${savedDateString.substring(6,10)} ${savedHourFimString.substring(0,2)}:${savedHourFimString.substring(3,5)}"
            val parsableDatefim: LocalDateTime = LocalDateTime.parse(parsableDateReservafim,formatter)

            Log.d("DateFormat dayHoje->", ""+dataHojeDate)
            Log.d("DateFormat dayReserva->", ""+dataReservaDate)

            if(dataHojeDate > dataReservaDate){
                Toast.makeText(applicationContext,"ERRO:Não pode fazer Reuniões no passado", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if(horafim < horainicio){
                Toast.makeText(applicationContext,"ERRO:hora de Inicío da Reunião é mais tarde que a hora de Fim da Reunião",
                    Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if(horafim == horainicio){
                Toast.makeText(applicationContext,"ERRO:hora de Inicío da Reunião é a mesma que a hora de Fim da Reunião",
                    Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            updatedataReserva = dataReservaDate.toString()
            updatehoraInicio = dataReservaDate.toString()
            updatehoraFim = parsableDatefim.toString()

            registerSala()

        }

    }
    override fun onDateSet(view: DatePicker?, dayOfMonth: Int, month: Int, year: Int) {

        savedDay = dayOfMonth
        savedMonth = (month+1)
        savedYear = year

        val etdataReserva = findViewById<EditText>(R.id.et_dataReserva)
        etdataReserva.hint= "$savedYear-$savedMonth-$savedDay"
        if(savedDay <10){
            etdataReserva.hint= "$savedYear-$savedMonth-0$savedDay"
        }
        if(savedMonth <10){
            etdataReserva.hint= "$savedYear-0$savedMonth-$savedDay"
            if(savedDay<10){
                etdataReserva.hint= "$savedYear-0$savedMonth-0$savedDay"
            }
        }
        savedDateString = etdataReserva.hint.toString()
        Log.d("Data Guardadas->", savedDateString)
    }
    override fun onTimeSet(view: TimePicker?, hourOfDay: Int, minute: Int) {

        val ethoraInicio = findViewById<EditText>(R.id.et_Inicio)
        val ethoraFim = findViewById<EditText>(R.id.et_Fim)
        if(isInicio==0){
            savedHoraFim = hourOfDay
            savedMinutoFim = minute
            ethoraFim.hint = "$savedHoraFim:$savedMinutoFim"
            if(savedMinutoFim < 10){
                ethoraFim.hint = "$savedHoraFim:0$savedMinutoFim"
            }
            if(savedHoraFim <10){
                ethoraFim.hint = "0$savedHoraFim:$savedMinutoFim"
                if(savedMinutoFim < 10){
                    ethoraFim.hint = "0$savedHoraFim:0$savedMinutoFim"
                }
            }
        }
        if(isInicio == 1){
            savedHoraInicio=hourOfDay
            savedMinutoInicio = minute
            ethoraInicio.hint = "$savedHoraInicio:$savedMinutoInicio"
            if(savedMinutoInicio <10){
                ethoraInicio.hint = "$savedHoraInicio:0$savedMinutoInicio"
            }
            if(savedHoraInicio <10){
                ethoraInicio.hint = "0$savedHoraInicio:$savedMinutoInicio"
                if(savedMinutoInicio < 10){
                    ethoraInicio.hint = "0$savedHoraInicio:0$savedMinutoInicio"
                }
            }
        }
    }


}