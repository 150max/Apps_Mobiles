package com.example.pintfinalissima

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import com.example.pintfinalissima.databinding.ActivityListaReservasBinding

class ListaReservas : AppCompatActivity(), ReservasItemClicked {
    private lateinit var mAdapter: ReservasListAdapter
    lateinit var preferences: SharedPreferences
    private  lateinit var binding : ActivityListaReservasBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lista_reservas)
        binding = ActivityListaReservasBinding.inflate(layoutInflater)
        setContentView(binding.root)


        val rvReservas = findViewById<RecyclerView>(R.id.recyclerViewReservas)
        rvReservas.layoutManager = LinearLayoutManager(this)
        BuscarData()
        mAdapter = ReservasListAdapter(this)

        rvReservas.adapter = mAdapter

        binding.buttonBack5.setOnClickListener {

            val intent = Intent(this, MainActivity2::class.java)
            startActivity(intent)
        }



    }
    private fun BuscarData() {
        preferences = getSharedPreferences("sharedpref", Context.MODE_PRIVATE)
        val id = preferences.getString("ID","")
        Log.d("API", "test => $id")
        val url = "https://backend-pint-final.herokuapp.com/api/mobile/reservaByUti/$id"
        val jsonObjectRequest = JsonObjectRequest(Request.Method.GET, url, null, {
                try {
                    val reservasJsonArray = it.getJSONArray("data")
                    val reservasArray = ArrayList<Reserva>()
                    for(i in 0 until reservasJsonArray.length()) {
                        val reservasJsonObject = reservasJsonArray.getJSONObject(i)
                        val reservas = Reserva(
                            reservasJsonObject.getInt("id_reserva"),
                            reservasJsonObject.getString("nome_centro"),
                            reservasJsonObject.getString("id_sala"),
                            reservasJsonObject.getString("data"),
                            reservasJsonObject.getString("horainicio"),
                            reservasJsonObject.getString("horafim"),
                            reservasJsonObject.getString("nome_sala"),
                            )
                        Log.d("API", "testReservas => $reservas")
                        reservasArray.add(reservas)
                    }
                    mAdapter.updateReservas(reservasArray)
                }catch (e: NumberFormatException)
                {
                    var error = it.getJSONObject("error").getString("message")
                    Toast.makeText(applicationContext,"ERRO: $error",Toast.LENGTH_SHORT).show()
                }
            },
            { error ->
                Log.d("API", "errorLista => $error")
                Toast.makeText(applicationContext,"ERRO: $error",Toast.LENGTH_SHORT).show()
            }
        )
        MySingleton.getInstance(this).addToRequestQueue(jsonObjectRequest)
    }
    override fun onItemClicked(item: Reserva) {
        val idReservaClicked = item.id_reserva

        val intent = Intent(this, DetalhesReserva::class.java)
        intent.putExtra("id_reserva",idReservaClicked)
        startActivity(intent)




    }


}