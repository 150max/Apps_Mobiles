package com.example.pintfinalissima

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

class EditarReserva : AppCompatActivity(), DatePickerDialog.OnDateSetListener, TimePickerDialog.OnTimeSetListener {

    private var savedDay = 0
    private var savedMonth = 0
    private var savedYear = 0
    private var savedHourInicio = 0
    private var savedMinuteInicio = 0
    private var savedHourFim = 0
    private var savedMinuteFim = 0
    private var isInicio = 0
    private var showMonth = 0
    private var savedDateString= ""
    private var savedHourInicioString = ""
    private var savedHourFimString = ""
    private var idSala = 0
    private var idReserva =0
    private var updatedataReserva = ""
    private var updatehoraInicio = ""
    private var updatehoraFim = ""




    private fun updateReserva(){
        val jsonObject = JSONObject()
        val url ="https://backend-pint-final.herokuapp.com/api/mobile/reserva/$idReserva"
        jsonObject.put("data", updatedataReserva)
        jsonObject.put("horainicio", updatehoraInicio)
        jsonObject.put("horafim", updatehoraFim)
        Log.d("API recebe->", jsonObject.toString())
        val req = JsonObjectRequest(
            Request.Method.PUT, url,jsonObject,
            { response ->
                // response
                if(response.getBoolean("sucesso")){
                    Toast.makeText(applicationContext,"Update a reserva confirmado!", Toast.LENGTH_SHORT).show()
                }else{
                    Toast.makeText(applicationContext,"Sala já ocupada, ir consultar horario!", Toast.LENGTH_SHORT).show()
                }
            },
            { error ->
                Log.d("API", "error => $error")

                Toast.makeText(applicationContext,"Sala já ocupada, ir consultar horario!", Toast.LENGTH_SHORT).show()
            }
        )
        MySingleton.getInstance(this).addToRequestQueue(req)
    }

    @RequiresApi(Build.VERSION_CODES.O)//Adicionado para usar o LocalDateTime
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_editar_reserva)
        val etdataReserva = findViewById<EditText>(R.id.et_dataReserva)
        val ethoraInicio = findViewById<EditText>(R.id.et_Inicio)
        val ethoraFim = findViewById<EditText>(R.id.et_Fim)
        val btnConfirmar = findViewById<Button>(R.id.buttonConfirmar)
        idReserva= intent.getIntExtra("id_reserva",0)
        idSala = 0
        val btnBack = findViewById<Button>(R.id.buttonBack)
        btnBack.setOnClickListener {
            val intent = Intent(this, DetalhesReserva::class.java)
            intent.putExtra("id_reserva",idReserva)
            startActivity(intent)
            this.finish()
        }
        val url = "https://backend-pint-final.herokuapp.com/api/mobile/reserva/$idReserva"
        val req = JsonObjectRequest(Request.Method.GET, url, null, { response ->
                // response
             try {
                 var jsonArray = JSONArray()
                 jsonArray = response.getJSONArray("data")
                 for (i in 0 until jsonArray.length()) {
                     val JsonResp = jsonArray.getJSONObject(i)
                     etdataReserva.hint = JsonResp.getString("data")
                     ethoraInicio.hint = JsonResp.getString("horainicio").substring(0,5)
                     ethoraFim.hint = JsonResp.getString("horafim").substring(0,5)
                     savedDay = JsonResp.getString("data").substring(0,2).toInt()
                     savedMonth = JsonResp.getString("data").substring(3,5).toInt() -1
                     savedYear = JsonResp.getString("data").substring(6,10).toInt()
                     savedHourInicio = JsonResp.getString("horainicio").substring(0,2).toInt()
                     savedMinuteInicio = JsonResp.getString("horainicio").substring(3,5).toInt()
                     savedHourFim = JsonResp.getString("horafim").substring(0,2).toInt()
                     savedMinuteFim = JsonResp.getString("horafim").substring(3,5).toInt()
             }
                }catch (e: JSONException) {
                 e.printStackTrace()
             }

        },
            { error ->
                Log.d("API", "error => $error")
                Toast.makeText(applicationContext,"ERRO: $error", Toast.LENGTH_SHORT).show()
            }
        )
        MySingleton.getInstance(this).addToRequestQueue(req)

        val btn_dataReserva= findViewById<Button>(R.id.buttonpopupdata)
        btn_dataReserva.setOnClickListener {
            DatePickerDialog(this,this,savedYear,savedMonth,savedDay).show()
        }
        val btn_horaInicio = findViewById<Button>(R.id.buttoninicio)
        btn_horaInicio.setOnClickListener {
            isInicio=1
            TimePickerDialog(this,this,savedHourInicio,savedMinuteInicio,true).show()
        }
        val btn_horaFim = findViewById<Button>(R.id.buttonFim)
        btn_horaFim.setOnClickListener {
            isInicio=0
            TimePickerDialog(this,this,savedHourFim,savedMinuteFim,true).show()
        }

        btnConfirmar.setOnClickListener {




            savedHourFimString = ethoraFim.hint.toString()
            Log.d("Hora Fim Guardada->",savedHourFimString)
            savedHourInicioString = ethoraInicio.hint.toString()
            Log.d("Hora Inicio Guardada->",savedHourInicioString)

            val horainicio = "${savedHourInicioString.substring(0,2)}.${savedHourInicioString.substring(3,5)}".toFloat()
            val horafim = "${savedHourFimString.substring(0,2)}.${savedHourFimString.substring(3,5)}".toFloat()

            val current = LocalDateTime.now()
            val formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")
            val dataHoje = current.format(formatter)
            val dataHojeDate: LocalDateTime = LocalDateTime.parse(dataHoje,formatter)
            savedDateString = etdataReserva.hint.toString()

            val parsableDateReserva = "${savedDateString.substring(0,2)}/${savedDateString.substring(3,5)}/${savedDateString.substring(6,10)} ${savedHourInicioString.substring(0,2)}:${savedHourInicioString.substring(3,5)}"
            val dataReservaDate: LocalDateTime = LocalDateTime.parse(parsableDateReserva,formatter)

            val parsableDateReservafim = "${savedDateString.substring(0,2)}/${savedDateString.substring(3,5)}/${savedDateString.substring(6,10)} ${savedHourFimString.substring(0,2)}:${savedHourFimString.substring(3,5)}"
            val parsableDatefim: LocalDateTime = LocalDateTime.parse(parsableDateReservafim,formatter)

            Log.d("DateFormat dayHoje->", ""+dataHojeDate)
            Log.d("DateFormat dayReserva->", ""+dataReservaDate)

            if(dataHojeDate > dataReservaDate){
                Toast.makeText(applicationContext,"ERRO:Não pode fazer Reuniões no passado", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if(horafim < horainicio){
                Toast.makeText(applicationContext,"ERRO:hora de Inicío da Reunião é mais tarde que a hora de Fim da Reunião",
                    Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if(horafim == horainicio){
                Toast.makeText(applicationContext,"ERRO:hora de Inicío da Reunião é a mesma que a hora de Fim da Reunião",
                    Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            updatedataReserva = dataReservaDate.toString()
            updatehoraInicio = dataReservaDate.toString()
            updatehoraFim = parsableDatefim.toString()
            updateReserva()






        }


    }
    override fun onDateSet(view: DatePicker?, dayOfMonth: Int, month: Int, year: Int) {
        savedDay = dayOfMonth
        savedMonth = month
        savedYear = year
        showMonth = savedMonth +1


        val etdataReserva = findViewById<EditText>(R.id.et_dataReserva)
        etdataReserva.hint= "$savedYear-$showMonth-$savedDay"
        if(savedDay <10){
            etdataReserva.hint= "$savedYear-$showMonth-0$savedDay"
        }
        if(showMonth <10){
            etdataReserva.hint= "$savedYear-0$showMonth-$savedDay"
            if(savedDay<10){
                etdataReserva.hint= "$savedYear-0$showMonth-0$savedDay"
            }
        }
        savedDateString = etdataReserva.hint.toString()
    }
    override fun onTimeSet(view: TimePicker?, hourOfDay: Int, minute: Int) {
        val ethoraInicio = findViewById<EditText>(R.id.et_Inicio)
        val ethoraFim = findViewById<EditText>(R.id.et_Fim)
        if(isInicio==0){
            savedHourFim = hourOfDay
            savedMinuteFim = minute
            ethoraFim.hint = "$savedHourFim:$savedMinuteFim"
            if(savedMinuteFim < 10){
                ethoraFim.hint = "$savedHourFim:0$savedMinuteFim"
            }
            if(savedHourFim <10){
                ethoraFim.hint = "0$savedHourFim:$savedMinuteFim"
                if(savedMinuteFim < 10){
                    ethoraFim.hint = "0$savedHourFim:0$savedMinuteFim"
                }
            }
        }
        if(isInicio == 1){
            savedHourInicio=hourOfDay
            savedMinuteInicio = minute
            ethoraInicio.hint = "$savedHourInicio:$savedMinuteInicio"
            if(savedMinuteInicio <10){
                ethoraInicio.hint = "$savedHourInicio:0$savedMinuteInicio"
            }
            if(savedHourInicio <10){
                ethoraInicio.hint = "0$savedHourInicio:$savedMinuteInicio"
                if(savedMinuteInicio < 10){
                    ethoraInicio.hint = "0$savedHourInicio:0$savedMinuteInicio"
                }
            }
        }
    }

}