package com.example.pintfinalissima

import android.graphics.Typeface
import android.text.Spannable
import android.text.SpannableString
import android.text.SpannableStringBuilder
import android.text.style.StyleSpan
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ReservasListAdapter(private val listener: ReservasItemClicked): RecyclerView.Adapter<ReservasViewHolder>() {
    private val items : ArrayList<Reserva> = ArrayList()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ReservasViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_reservas, parent, false)
        val viewHolder= ReservasViewHolder(view)
        view.setOnClickListener{
            listener.onItemClicked(items[viewHolder.adapterPosition])
        }
        return viewHolder
    }

    override fun getItemCount(): Int {
        return items.size
    }

    override fun onBindViewHolder(holder: ReservasViewHolder, position: Int) {
        val currentItem = items[position]

        val textid_centro = currentItem.id_centro
        val textid_sala =currentItem.nome_sala
        val textdata = currentItem.data
        val texthorainicio =currentItem.horainicio
        val texthorafim = currentItem.horafim

        holder.id_centroview.text = textid_centro
        holder.id_salaview.text = textid_sala
        holder.dataview.text = textdata
        holder.horainicioview.text = texthorainicio
        holder.horafimview.text = texthorafim

    }
    fun updateReservas(updateReservas: ArrayList<Reserva>){
        items.clear()
        items.addAll(updateReservas)
        notifyDataSetChanged()
    }
}

class ReservasViewHolder(itemView: View): RecyclerView.ViewHolder(itemView){
    val id_centroview = itemView.findViewById<TextView>(R.id.id_centro)
    val id_salaview = itemView.findViewById<TextView>(R.id.id_sala)
    val dataview = itemView.findViewById<TextView>(R.id.data)
    val horainicioview = itemView.findViewById<TextView>(R.id.horainicio)
    val horafimview = itemView.findViewById<TextView>(R.id.horafim)
}
interface ReservasItemClicked {
    fun onItemClicked(item: Reserva)
}