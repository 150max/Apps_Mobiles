package com.example.pintfinalissima.models

import android.widget.EditText

data class SignInBody(
    val email: String,
    val password: String)
