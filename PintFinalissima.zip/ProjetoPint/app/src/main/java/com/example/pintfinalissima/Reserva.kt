package com.example.pintfinalissima

class Reserva (
    val id_reserva: Int,
    val id_centro: String,
    val id_sala: String,
    val data: String,
    val horainicio: String,
    val horafim: String,
    val nome_sala: String)

