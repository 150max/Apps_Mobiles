package com.example.pintfinalissima

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import com.example.pintfinalissima.databinding.ActivityMudarPassBinding
import org.json.JSONObject

class MudarPass : AppCompatActivity() {
    lateinit var preferences: SharedPreferences
    private  lateinit var binding : ActivityMudarPassBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mudar_pass)

        binding = ActivityMudarPassBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.buttonBack10.setOnClickListener {

            val intent = Intent(this, MainActivity2::class.java)
            startActivity(intent)
        }

        val bu = findViewById<Button>(R.id.btn_Alterarr)

        bu.setOnClickListener {
            signin()
        }
    }
        private fun signin(){
            val edt1 = findViewById<EditText>(R.id.OldPassword)
            val edt2 = findViewById<EditText>(R.id.Password)
            val edt3 = findViewById<EditText>(R.id.ConfirmarPassword)

            preferences = getSharedPreferences("sharedprefp", Context.MODE_PRIVATE)
            val Oldpass = preferences.getString("passwordF","")

            Log.d("Valor do edt1", edt1.text.toString())
            Log.d("Valor do edt2", edt2.text.toString())
            Log.d("Valor do edt3", edt3.text.toString())
            if (Oldpass != null) {
                Log.d("Valor do Oldpass", Oldpass)
            }

            val Pass1 = edt1.text.toString()
            val Pass2 = edt2.text.toString()
            val Pass3 = edt3.text.toString()
            preferences = getSharedPreferences("sharedpref", Context.MODE_PRIVATE)
            val id = preferences.getString("ID","")

            if (Oldpass != null && Oldpass==Pass1) {

                    if (Pass2 == Pass3)
                    {
                        val jsonObject = JSONObject()
                        jsonObject.put("password", Pass3)
                        val url = "https://backend-pint-final.herokuapp.com/api/mobile/resetpassword/${id}"
                        val req = JsonObjectRequest(Request.Method.PUT, url,jsonObject, { response ->
                                // response
                                if (response.has("data")) {
                                    Toast.makeText(applicationContext,"Pass alterada com sucesso", Toast.LENGTH_SHORT).show()
                                    val intent = Intent(this, MainActivity2::class.java)
                                    startActivity(intent)
                                    this.finish()
                                } else {
                                    var strErro = response.getJSONObject("data").getString("name")
                                    Toast.makeText(applicationContext, "ERRO: $strErro", Toast.LENGTH_SHORT).show()
                                }

                            },
                            { error -> Log.d("API", "error => $error")
                                Toast.makeText(applicationContext, "ERRO: $error", Toast.LENGTH_SHORT).show()
                            }
                        )

                        MySingleton.getInstance(this).addToRequestQueue(req)

                    }
            }
        }

}

