package com.example.pintfinalissima

class Centro  (
    val id_centro: String,
    val nome_centro: String,
    val morada: String,
    val estado: String
    )

