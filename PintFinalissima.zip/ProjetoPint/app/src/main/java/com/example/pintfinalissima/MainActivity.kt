package com.example.pintfinalissima

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import com.example.pintfinalissima.API.ApiInterface
import com.example.pintfinalissima.API.RetrofitInstance
import com.example.pintfinalissima.models.SignInBody
import okhttp3.ResponseBody
import org.json.JSONArray
import org.json.JSONException
import retrofit2.Call
import retrofit2.Callback

class MainActivity : AppCompatActivity() {

    lateinit var sharedPreferences: SharedPreferences
    lateinit var sharedPreferences2: SharedPreferences
    lateinit var sharedPreferences3: SharedPreferences



    private fun checkPasswordUpdate(id_utilizador: String){
        val url ="https://backend-pint-final.herokuapp.com/api/mobile/utilizador/$id_utilizador"
        val request = JsonObjectRequest(Request.Method.GET, url, null, { response ->

            try{
                var jsonArray = JSONArray()
                jsonArray = response.getJSONArray("dados")
                for (i in 0 until jsonArray.length()) {
                    val JsonResp = jsonArray.getJSONObject(i)

                    val verificar = false;

                    val v = verificar.toString()

                    if (v == JsonResp.getString("pass"))
                    {
                        val intent = Intent(this, MudarPass::class.java)
                        startActivity(intent)
                        this.finish()
                    }

                }
            }
            catch (e: JSONException) {
                e.printStackTrace()
            }

        },
            { error ->
                Log.d("API", "error => $error")
                Toast.makeText(applicationContext,"ERRO: $error", Toast.LENGTH_SHORT).show()
            }
        )

        MySingleton.getInstance(this).addToRequestQueue(request)


    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val loginbtn = findViewById<Button>(R.id.btn_Alterar)
        loginbtn.setOnClickListener {
            signin()

    }

}
    private fun signin(){
        val email = findViewById<EditText>(R.id.etPassword)
        val password = findViewById<EditText>(R.id.etConfirmarPassword)
        val loginbtn = findViewById<Button>(R.id.btn_Alterar)


        val emailF = email.text.toString().trim()
        val passwordF = password.text.toString().trim()

        sharedPreferences2 = getSharedPreferences("sharedprefp", Context.MODE_PRIVATE)
        val editor:SharedPreferences.Editor=sharedPreferences2.edit()
        editor.putString("passwordF",passwordF)
        editor.apply()

        sharedPreferences3 = getSharedPreferences("sharedprefp2", Context.MODE_PRIVATE)
        val editor1:SharedPreferences.Editor=sharedPreferences3.edit()
        editor1.putString("emailF",emailF)
        editor1.apply()

        if (emailF.isNullOrEmpty())
        {
            email.error = "Por favor inserir o email"
        }
        else if (passwordF.isNullOrEmpty())
        {
            password.error = "Por favor inserir a pass"
        }
        else {

            var dialog = Dialog(this, android.R.style.Theme_Translucent_NoTitleBar)
            val view = layoutInflater.inflate(R.layout.fullscreen_progress_bar, null)
            dialog.setContentView(view)
            dialog.setCancelable(false)
            dialog.show()

            val retIn = RetrofitInstance.getRetrofitInstance().create(ApiInterface::class.java)
            val signInInfo = SignInBody(emailF, passwordF)
            retIn.signin(signInInfo).enqueue(object : Callback<ResponseBody> {
                override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                    Toast.makeText(this@MainActivity, "Login failed!", Toast.LENGTH_SHORT).show()
                }

                override fun onResponse(
                    call: Call<ResponseBody>,
                    response: retrofit2.Response<ResponseBody>
                ) {
                    if (response.code() == 200) {

                        val id = response.body()?.string().toString()
                        Log.d("Valor do id", id)


                        sharedPreferences = getSharedPreferences("sharedpref", Context.MODE_PRIVATE)
                        val editor: SharedPreferences.Editor = sharedPreferences.edit()
                        editor.putString("ID", id)
                        editor.apply()
                        checkPasswordUpdate(id)

                        val intent = Intent(this@MainActivity, MainActivity2::class.java)
                        startActivity(intent)
                        finish()
                        dialog.dismiss()



                        //igualar uma variavel glogal a variavel id que vem e armazenar numa shared preference !!!
                    } else {
                        Toast.makeText(this@MainActivity, "Credenciais inválidas.", Toast.LENGTH_SHORT).show()
                        dialog.dismiss()


                    }


                }


            })

        }
    }

}
