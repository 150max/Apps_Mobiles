package com.example.pintfinalissima

import android.content.DialogInterface
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.text.Spannable
import android.text.SpannableString
import android.text.SpannableStringBuilder
import android.text.style.StyleSpan
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import org.json.JSONArray
import org.json.JSONException


class DetalhesReserva : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detalhes_reserva)

        val dataReserva = findViewById<TextView>(R.id.tv_DataReuniao)
        val horaInicio = findViewById<TextView>(R.id.tv_horaInicio)
        val horaFim = findViewById<TextView>(R.id.tv_horaFim)
        val Nomesala = findViewById<TextView>(R.id.Sala)
        val btnEditarReserva = findViewById<Button>(R.id.btn_EditarReserva)




        val idReserva:Int = intent.getIntExtra("id_reserva",0)
        fetchdata(dataReserva,horaInicio,horaFim,Nomesala,idReserva)
        btnEditarReserva.setOnClickListener {

            val intent = Intent(this, EditarReserva::class.java)
            intent.putExtra("id_reserva",idReserva)
            Log.d("APIx0", idReserva.toString())
            startActivity(intent)
            Log.d("APIx1", idReserva.toString())

        }
        print("o Valor éx2"+idReserva)
        val btnBack = findViewById<Button>(R.id.btn_back)
        btnBack.setOnClickListener {
            val intent = Intent(this, ListaReservas::class.java)
            startActivity(intent)
        }

        val btnCancelar = findViewById<Button>(R.id.buttonCancelar)
        btnCancelar.setOnClickListener {
            val url ="https://backend-pint-final.herokuapp.com/api/mobile/reserva/$idReserva"
            var builder = AlertDialog.Builder(this)
            builder.setTitle("Cancelar Reserva")
            builder.setMessage("Tem a certeza que quer Cancelar a Reserva?")
            builder.setPositiveButton("SIM", DialogInterface.OnClickListener{ dialog, id ->
                val req = JsonObjectRequest(Request.Method.DELETE, url, null, Response.Listener { response ->
                    // response
                        if(response.has("data")){
                            Toast.makeText(applicationContext,"Reserva Cancelada", Toast.LENGTH_SHORT).show()
                            val intent = Intent(this, ListaReservas::class.java)
                            startActivity(intent)
                        }else{
                            var strErro = response.getJSONObject("data")
                            Toast.makeText(applicationContext,"ERRO: $strErro", Toast.LENGTH_SHORT).show()
                        }
                    }
                )
                { error ->
                    Log.d("API", "error => $error")
                    Toast.makeText(applicationContext, "ERRO: $error", Toast.LENGTH_SHORT).show()
                }

                MySingleton.getInstance(this).addToRequestQueue(req)
            })
            builder.setNegativeButton("NÃO", DialogInterface.OnClickListener{ dialog, id ->
                dialog.cancel()
            })
            var alert = builder.create()
            alert.show()

        }
    }

    private fun fetchdata(data: TextView, horainicio: TextView, horafim: TextView,Nomesala: TextView,id_reserva: Int) {

        val url ="https://backend-pint-final.herokuapp.com/api/mobile/reserva/$id_reserva"
        val request = JsonObjectRequest(Request.Method.GET, url, null, { response ->
                // response
                try{
                    var jsonArray = JSONArray()
                    jsonArray = response.getJSONArray("data")
                    for (i in 0 until jsonArray.length()) {
                        val JsonResp = jsonArray.getJSONObject(i)

                        data.text = JsonResp.getString("data")
                        horainicio.text = JsonResp.getString("horainicio")
                        horafim.text = JsonResp.getString("horafim")
                        Nomesala.text = JsonResp.getString("nome_sala")

                    }
                }
                catch (e: JSONException) {
                    e.printStackTrace()
                }

            },
            { error ->
                Log.d("API", "error => $error")
                Toast.makeText(applicationContext,"ERRO: $error", Toast.LENGTH_SHORT).show()
            }
        )

        MySingleton.getInstance(this).addToRequestQueue(request)

    }


}

