package com.example.pintfinalissima

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.widget.RelativeLayout
import android.widget.TextView
import com.example.pintfinalissima.databinding.ActivityMain2Binding

class MainActivity2 : AppCompatActivity() {

    lateinit var preferences: SharedPreferences

    private lateinit var binding : ActivityMain2Binding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        binding= ActivityMain2Binding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.cardview1.setOnClickListener {

            val intent = Intent(this@MainActivity2, ListaCentros::class.java)
            startActivity(intent)
            true
        }

        binding.cardview2.setOnClickListener {

            val intent = Intent(this@MainActivity2, ListaReservas::class.java)
            startActivity(intent)
            true
        }


        binding.cardview3.setOnClickListener {

            val intent = Intent(this@MainActivity2, MudarPass::class.java)
            startActivity(intent)
            true
        }

        binding.cardview4.setOnClickListener {

            val intent = Intent(this@MainActivity2, Scann::class.java)
            startActivity(intent)
            true
        }



        val z = findViewById<TextView>(R.id.textView2)
        preferences = getSharedPreferences("sharedprefp2", Context.MODE_PRIVATE)
        val zz = preferences.getString("emailF","").toString()
        z.text=zz


    }

}