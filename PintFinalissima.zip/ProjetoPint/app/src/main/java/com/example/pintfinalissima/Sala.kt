package com.example.pintfinalissima

class Sala (
    val id_sala: Int,
    val nome_sala: String,
    val lotacao: String,
    val estado: String,
    val limite: String,
    val maximo: String
    )
